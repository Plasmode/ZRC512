9/26/23
Modify the Z80LCD to RomWBW

replace 128K RAM with 512K RAM, cut VCC connection to pin 30.  Need to cut connection at solder side as well as comp side and jumper VCC to pin 32.
Connect T4 to pin 30 of RAM
connect T5 to pin 1 of RAM
This provides 16 banks of 32K RAM per bank

Replace the ROM with Z80ALL ROM which always boot from CF disk.  This reduce logic utilization to 102 macrocells

Check everything out with default Z80LCD CF disk.  It still boots OK.

Now, need to add hardware serial transmit as well as making the bank register compatible with RomWBW.  Use ZRC design file as reference.

change serial IO addresses to 0x80 and 0x81 to emulate 6850
-----------------
This is basically a 22MHz ZRC.  Use ZRC design file, but pin assignment of Z80LCD