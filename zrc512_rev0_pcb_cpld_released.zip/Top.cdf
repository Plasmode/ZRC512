/* Quartus II Version 8.1 Build 163 10/28/2008 SJ Full Version */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM7128SL84) Path("C:/quartwrk81/HomeProjects/ZRC512/") File("Top.pof") MfrSpec(OpMask(3));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
