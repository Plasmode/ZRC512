;Bootstrap ROM inside CPLD
;boot from serial port or CF disk or jump blindly into RAM
; spinning for a 4 seconds looking for serial port input
; at 2 second point, execute a blind CF read sector command
; Must send 256 bytes of serial data within 3 seconds
; if no serial input at end of 4 seconds, check CF busy flag
; if CF is not busy, read 256 words of CF data
; if CF is busy, jump to 0xb000
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; CPLDCF, Copyright (C) 2020 Hui-chien Shen
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

SerData equ 081h 	; CPLD UART receive register
SerStat equ 080h 	; CPLD UART transmitter status/control register

CFData	equ 10h		;CF data register
CFstat   	equ 17h       	;CF status/command reg

	org 0

	ld hl,0b000h 	;bootstrap code starts from 0xb000
	ld b,9h		;this is roughly 4 seconds of delay		
; examine the serial data ready flag
readbsy:
	in a,(SerStat) 	;read serial port data ready flag
	rra 		;bit 0 is serial data ready
	jr c,serboot 	;if serial data ready, do serial bootstrap
spin:
	inc de 		;delay loop
	ld a,d		;look for reg DE=0
	or e
	jr nz,readbsy
	ld a,b
	cp 4		; in mid point of count down, send out read CF sector command
	jr nz,spin1
	ld a,20h		;read CF sector command
	out (CFstat),a
spin1:
	or '0'		;offset to readable characters
	out (SerData),a	;show countdown on serial port
	dec b 		;9 delay loops
	jr nz,readbsy
	in a,(CFstat)	; check data request bit set before read in CF data
	rla		; roll msb into carry flag
	jr c,jumpRAM	; if still busy, then CF drive is not present
	ld c,CFData
	inir		;z80 read 256 bytes, HL is now pointed to 0xb100
	dec h
jumpRAM:
	jp (hl)		;jump to 0xb000
;serial input detected
;load 256 bytes of serial bootstrap code
serboot:
	in a,(SerData) 	;read data
	ld (hl),a 	;save program
	inc l
	jr nz,readbsy
	jp (hl) 		;jump to 0xb000

	end

